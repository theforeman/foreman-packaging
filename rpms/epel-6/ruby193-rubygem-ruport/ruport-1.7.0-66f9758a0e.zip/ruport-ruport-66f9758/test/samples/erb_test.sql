select * from <%= @table %>
