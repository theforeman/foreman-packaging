select * from foo
