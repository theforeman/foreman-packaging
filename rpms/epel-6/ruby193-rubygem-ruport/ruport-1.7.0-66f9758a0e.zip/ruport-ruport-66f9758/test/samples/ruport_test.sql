create table ruport_test (
  a varchar(55),
  b varchar(55),
  c varchar(55),
  d varchar(55)
);
insert into ruport_test values( 'a column, row 1', 'b column, row 1', 'c column, row 1', 'd column, row 1' );
SELECT * FROM ruport_test;
