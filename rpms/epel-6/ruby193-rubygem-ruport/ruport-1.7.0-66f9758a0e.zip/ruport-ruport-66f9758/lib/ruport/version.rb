module Ruport
  VERSION = "1.7.0"
end
